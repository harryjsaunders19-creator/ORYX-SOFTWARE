import * as XLSX from "xlsx"
import type { AccountsHandoverSnapshot } from "@/lib/db"

const NOT_TRACKED = "—"

/**
 * Builds the 8-sheet Accounts Handover workbook. Used both at export time
 * (fresh snapshots, real batch number) and when re-downloading a past batch
 * (snapshots loaded back from BillingExportSnapshot — byte-identical output
 * since nothing here re-reads live Job/Client data).
 *
 * Sheet order matches the business requirement exactly: Accounts Summary,
 * Project Details, Client Information, Commercial Information, Design &
 * Survey Information, Revision History, Activity Log / Audit Trail,
 * Attachments & Documents.
 */
export function buildAccountsHandoverWorkbook(
  snapshots: AccountsHandoverSnapshot[],
  meta: { batchNumber: string; exportDate: string; exportedBy: string },
) {
  const wb = XLSX.utils.book_new()

  // ── Sheet 1: Accounts Summary ──────────────────────────────────
  const summaryHeader = [
    ["Accounts Handover"],
    ["Batch Number", meta.batchNumber],
    ["Export Date", meta.exportDate],
    ["Exported By", meta.exportedBy],
    ["Record Count", snapshots.length],
    [],
    ["Job Number", "Project Name", "Client", "Site Address", "Job Type", "Job Status", "Completion Date", "Assigned Designer", "Agreed Fee"],
  ]
  const summaryRows = snapshots.map(s => [
    s.project.jobNumber, s.project.projectName ?? NOT_TRACKED, s.client.clientName, s.project.siteAddress,
    s.billingEventType === "REVISION_COMPLETED" ? "Revision" : "Job",
    s.project.jobStatus, s.project.completionDate, s.design.assignedDesigner ?? NOT_TRACKED,
    s.commercial.agreedFee ?? "",
  ])
  const sheet1 = XLSX.utils.aoa_to_sheet([...summaryHeader, ...summaryRows])
  XLSX.utils.book_append_sheet(wb, sheet1, "Accounts Summary")

  // ── Sheet 2: Project Details ───────────────────────────────────
  const projectHeader = [
    "Job Number", "Drawing Number", "Project Name", "Project Description", "Site Address", "Type of Works",
    "Other Type Description", "Priority", "Status", "Creation Date", "Due Date", "Completion Date", "All Project Notes",
    "Requested By", "Company Requesting Works", "Request Date", "Request Source", "Internal References",
    "Purchase Order Number", "Cost Centre",
  ]
  const projectRows = snapshots.map(s => [
    s.project.jobNumber, s.project.drawingNumber, s.project.projectName ?? NOT_TRACKED,
    s.project.projectDescription ?? NOT_TRACKED, s.project.siteAddress, s.project.typeOfWorks ?? NOT_TRACKED,
    s.project.otherTypeDescription ?? NOT_TRACKED, s.project.priority ?? NOT_TRACKED, s.project.jobStatus,
    s.project.creationDate, s.project.dueDate ?? NOT_TRACKED, s.project.completionDate, s.project.allNotes ?? NOT_TRACKED,
    s.request.requestedBy ?? NOT_TRACKED, s.request.companyRequestingWorks, s.request.requestDate ?? NOT_TRACKED,
    s.request.requestSource ?? NOT_TRACKED, s.request.internalReferences ?? NOT_TRACKED,
    s.request.purchaseOrderNumber ?? NOT_TRACKED, s.request.costCentre ?? NOT_TRACKED,
  ])
  const sheet2 = XLSX.utils.aoa_to_sheet([projectHeader, ...projectRows])
  XLSX.utils.book_append_sheet(wb, sheet2, "Project Details")

  // ── Sheet 3: Client Information ────────────────────────────────
  const clientHeader = [
    "Job Number", "Client Name", "Company Name", "Contact Name", "Contact Email", "Contact Telephone",
    "Billing Contact", "Billing Address", "Client Notes",
  ]
  const clientRows = snapshots.map(s => [
    s.project.jobNumber, s.client.clientName, s.client.companyName, s.client.contactName ?? NOT_TRACKED,
    s.client.contactEmail ?? NOT_TRACKED, s.client.contactTelephone ?? NOT_TRACKED,
    s.client.billingContact ?? NOT_TRACKED, s.client.billingAddress ?? NOT_TRACKED, s.client.clientNotes ?? NOT_TRACKED,
  ])
  const sheet3 = XLSX.utils.aoa_to_sheet([clientHeader, ...clientRows])
  XLSX.utils.book_append_sheet(wb, sheet3, "Client Information")

  // ── Sheet 4: Commercial Information ────────────────────────────
  const commercialHeader = [
    "Job Number", "Client", "Agreed Fee", "Quoted Fee", "Quote Reference", "Variation Fees", "Additional Charges",
    "Revision Charges", "Commercial Notes", "Payment Terms",
  ]
  const commercialRows = snapshots.map(s => [
    s.project.jobNumber, s.client.clientName,
    s.commercial.agreedFee ?? "", s.commercial.quotedFee ?? "", s.commercial.quoteReference ?? NOT_TRACKED,
    s.commercial.variationFees ?? NOT_TRACKED, s.commercial.additionalCharges ?? NOT_TRACKED,
    s.commercial.revisionCharges ?? "", s.commercial.commercialNotes ?? NOT_TRACKED, s.commercial.paymentTerms ?? NOT_TRACKED,
  ])
  const sheet4 = XLSX.utils.aoa_to_sheet([commercialHeader, ...commercialRows])
  XLSX.utils.book_append_sheet(wb, sheet4, "Commercial Information")

  // ── Sheet 5: Design & Survey Information ───────────────────────
  const designHeader = [
    "Job Number", "Assigned Designer", "Completed By", "Design Completion Date", "Design Notes", "Design Reference",
    "Assigned Surveyor", "Survey Date", "Survey Notes", "Survey References",
  ]
  const designRows = snapshots.map(s => [
    s.project.jobNumber, s.design.assignedDesigner ?? NOT_TRACKED, s.design.completedBy ?? NOT_TRACKED,
    s.design.designCompletionDate, s.design.designNotes ?? NOT_TRACKED, s.design.designReference,
    s.survey.assignedSurveyor ?? NOT_TRACKED, s.survey.surveyDate ?? NOT_TRACKED,
    s.survey.surveyNotes ?? NOT_TRACKED, s.survey.surveyReferences ?? NOT_TRACKED,
  ])
  const sheet5 = XLSX.utils.aoa_to_sheet([designHeader, ...designRows])
  XLSX.utils.book_append_sheet(wb, sheet5, "Design & Survey Information")

  // ── Sheet 6: Revision History ──────────────────────────────────
  const revisionHeader = [
    "Parent Job Number", "Revision Drawing Number", "Revision Letter", "Status",
    "Requested Date", "Completion Date", "Revision Description / Notes", "Charge",
  ]
  const revisionRows = snapshots.flatMap(s =>
    s.revisions.history.map(r => [
      s.project.jobNumber, r.drawingNumber, r.revisionLetter ?? "", r.status,
      r.requestedDate ?? "", r.completionDate ?? "", r.description ?? NOT_TRACKED, r.charge ?? "",
    ])
  )
  const sheet6 = XLSX.utils.aoa_to_sheet([revisionHeader, ...revisionRows])
  XLSX.utils.book_append_sheet(wb, sheet6, "Revision History")

  // ── Sheet 7: Activity Log / Audit Trail ────────────────────────
  // Two parts per job: the summary fields, then every individual status
  // change as its own row underneath — the "full activity timeline" the
  // business requirement asks for, not just a created/modified summary.
  const auditSummaryHeader = [
    "Job Number", "Created By", "Created Date", "Last Modified By", "Last Modified Date",
    "Added To Queue At", "Batch Number", "Export Date", "Exported By",
  ]
  const auditSummaryRows = snapshots.map(s => [
    s.project.jobNumber, s.audit.createdBy ?? NOT_TRACKED, s.audit.createdDate,
    s.audit.lastModifiedBy ?? NOT_TRACKED, s.audit.lastModifiedDate, s.audit.addedToQueueAt,
    meta.batchNumber, meta.exportDate, meta.exportedBy,
  ])
  const timelineHeader = ["Job Number", "From Status", "To Status", "Changed By", "Changed At", "Note / Comment"]
  const timelineRows = snapshots.flatMap(s =>
    s.audit.fullHistory.map(h => [
      s.project.jobNumber, h.fromStatus ?? "(created)", h.toStatus, h.changedBy, h.changedAt, h.note ?? NOT_TRACKED,
    ])
  )
  const sheet7 = XLSX.utils.aoa_to_sheet([
    ["Audit Summary"],
    auditSummaryHeader, ...auditSummaryRows,
    [],
    ["Full Activity Timeline (every recorded status change, oldest first)"],
    timelineHeader, ...timelineRows,
  ])
  XLSX.utils.book_append_sheet(wb, sheet7, "Activity Log")

  // ── Sheet 8: Attachments & Documents ───────────────────────────
  const attachmentsHeader = ["Job Number", "File Name", "File Type", "Upload Date", "Uploaded By", "Document Category"]
  const attachmentsRows = snapshots.flatMap(s =>
    s.attachments.items.length
      ? s.attachments.items.map(a => [s.project.jobNumber, a.fileName, "", a.uploadedAt, "", a.reference])
      : [[s.project.jobNumber, NOT_TRACKED, NOT_TRACKED, NOT_TRACKED, NOT_TRACKED, NOT_TRACKED]]
  )
  const sheet8 = XLSX.utils.aoa_to_sheet([
    ["This application has no file upload or document storage of any kind — there is no attachment metadata anywhere in the system to export. Every row below is a placeholder, not a real lookup that came back empty."],
    [],
    attachmentsHeader, ...attachmentsRows,
  ])
  XLSX.utils.book_append_sheet(wb, sheet8, "Attachments & Documents")

  // ── Sheet 9: Notes — what isn't captured by this system ────────
  const notesLines = snapshots[0]?.notTracked ?? []
  const notesSheet = XLSX.utils.aoa_to_sheet([
    ["Notes on this export"],
    [],
    [`Cells marked "${NOT_TRACKED}" are fields this application does not currently capture — they are not blank by omission, the data simply doesn't exist in the system yet. If accounts regularly needs one of these, it's worth raising as a feature request rather than tracking it outside the app.`],
    [],
    ["Fields not currently tracked:"],
    ...notesLines.map(l => [l]),
  ])
  XLSX.utils.book_append_sheet(wb, notesSheet, "Notes")

  return wb
}

export function workbookToBuffer(wb: XLSX.WorkBook): Buffer {
  return XLSX.write(wb, { type: "buffer", bookType: "xlsx" }) as Buffer
}
