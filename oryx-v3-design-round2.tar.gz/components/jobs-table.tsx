"use client"
import { useState, useEffect, useCallback, useRef } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { format }    from "date-fns"
import {
  Search, Plus, Download, SlidersHorizontal,
  Pencil, Trash2, ChevronLeft, ChevronRight,
  X, FolderOpen, ArrowUp, ArrowDown, ArrowUpDown, GitBranch, AlertTriangle, Clock,
  MoreHorizontal, Building2, FileText, UserCircle2, PenTool,
} from "lucide-react"
import { Button }   from "@/components/ui/button"
import { Input }    from "@/components/ui/input"
import {
  Select, SelectContent, SelectItem,
  SelectTrigger, SelectValue,
} from "@/components/ui/select"
import {
  DropdownMenu, DropdownMenuTrigger, DropdownMenuContent,
  DropdownMenuItem, DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import {
  Dialog, DialogContent, DialogHeader, DialogFooter,
  DialogTitle, DialogDescription, DialogBody,
} from "@/components/ui/dialog"
import { JOB_ROW_BG } from "@/components/status-badge"
import { WorkItemTypeBadge } from "@/components/work-item-type-badge"
import { TypeOfWorksBadge } from "@/components/type-of-works-badge"
import { AssignDesignerModal } from "@/components/assign-designer-modal"
import { InlineStatusSelect, InlineDesignerSelect } from "@/components/inline-edit-selects"
import { JobForm }       from "@/components/job-form"
import { useToast }      from "@/components/ui/toast"
import { useUser }       from "@/components/user-context"
import { JOB_STATUSES, WORK_ITEM_TYPES, WORKS_TYPES, getJobStatus } from "@/lib/constants"
import { cn, formatGBP, getDeadlineInfo, parseLocalDate } from "@/lib/utils"
import type { Job, JobFormData, JobsResponse, SortField, SortDir } from "@/lib/types"

const LIMIT = 25

// Column visibility by breakpoint — mirrors the required mobile priority
// order (Drawing No. → Address → Completion Status → Type of Works →
// Client). Drawing No./Address/Completion Status have no hidden-* class
// below, since they must always be visible. Requested By, Quotation, and
// Designer are the least critical on a narrow screen, so they appear latest.
const COL_TYPE_OF_WORKS = "hidden sm:table-cell"
const COL_CLIENT        = "hidden sm:table-cell"
const COL_REQUESTED_BY  = "hidden md:table-cell"
const COL_QUOTATION     = "hidden lg:table-cell"
const COL_DESIGNER      = "hidden lg:table-cell"

function SkeletonRows() {
  return (
    <>
      {Array.from({ length: 8 }).map((_, i) => (
        <tr key={i} className="border-b border-bd">
          {[110, 200, 130, 130, 120, 90, 130, 110].map((w, j) => (
            <td key={j} className="px-4 py-3.5">
              <div className="skeleton h-4" style={{ width: w }} />
            </td>
          ))}
          <td className="px-4 py-3.5 w-16" />
        </tr>
      ))}
    </>
  )
}

function EmptyState({ hasFilters, onCreate, onClear }: {
  hasFilters: boolean; onCreate: () => void; onClear: () => void
}) {
  return (
    <tr>
      <td colSpan={9} className="py-16 text-center">
        <div className="inline-flex flex-col items-center gap-3">
          <div className="w-10 h-10 rounded border border-bd flex items-center justify-center bg-pg">
            <FolderOpen className="h-5 w-5 text-t4" />
          </div>
          <div>
            <p className="text-sm font-medium text-t1">{hasFilters ? "No jobs match" : "No jobs yet"}</p>
            <p className="text-xs text-t3 mt-0.5">
              {hasFilters ? "Try clearing your filters" : "Create your first job to get started"}
            </p>
          </div>
          {hasFilters
            ? <Button variant="outline" size="sm" onClick={onClear}>Clear filters</Button>
            : <Button variant="primary" size="sm" onClick={onCreate}><Plus className="h-3.5 w-3.5" />New job</Button>
          }
        </div>
      </td>
    </tr>
  )
}

function SortTh({ field, label, current, dir, onSort, className }: {
  field: SortField; label: string; current: SortField; dir: SortDir
  onSort: (f: SortField) => void; className?: string
}) {
  const active = current === field
  return (
    <th
      onClick={() => onSort(field)}
      className={cn(
        "px-4 py-2.5 text-left text-xs font-semibold text-t3 uppercase tracking-wider cursor-pointer select-none whitespace-nowrap",
        className,
      )}
    >
      <span className="inline-flex items-center gap-1">
        {label}
        {active
          ? dir === "asc" ? <ArrowUp className="h-3 w-3 text-t2" /> : <ArrowDown className="h-3 w-3 text-t2" />
          : <ArrowUpDown className="h-3 w-3 text-t4" />}
      </span>
    </th>
  )
}

export function JobsTable() {
  const router       = useRouter()
  const { toast }    = useToast()
  const { userName } = useUser()

  const [data,         setData]         = useState<JobsResponse | null>(null)
  const [holdClientIds, setHoldClientIds] = useState<Set<string>>(new Set())
  const [designers,    setDesigners]    = useState<string[]>([])
  const [loading,      setLoading]      = useState(true)
  const [search,       setSearch]       = useState("")
  const searchParams = useSearchParams()
  const [statusFilter,  setStatusFilter]  = useState(() => searchParams.get("status")  ?? "ALL")
  const [onlyOriginals, setOnlyOriginals] = useState(() => searchParams.get("onlyOriginals") === "true")
  const [onlyRevisions, setOnlyRevisions] = useState(() => searchParams.get("onlyRevisions") === "true")
  const [itemTypeFilter, setItemTypeFilter] = useState(() => searchParams.get("itemType") ?? "ALL")
  const [typeOfWorksFilter, setTypeOfWorksFilter] = useState(() => searchParams.get("typeOfWorks") ?? "ALL")
  const [deadlineFilter,  setDeadlineFilter]  = useState(() => searchParams.get("deadline") ?? "ALL")
  const initUnassigned = searchParams.get("unassigned") === "true"
  const [page,         setPage]         = useState(1)
  const [sortBy,       setSortBy]       = useState<SortField>("createdAt")
  const [sortDir,      setSortDir]      = useState<SortDir>("desc")
  const [showFilters,  setShowFilters]  = useState(false)
  const [createOpen,   setCreateOpen]   = useState(false)
  const [createSaving, setCreateSaving] = useState(false)
  const [editJob,      setEditJob]      = useState<Job | null>(null)
  const [editSaving,   setEditSaving]   = useState(false)
  const [deleteJob,    setDeleteJob]    = useState<Job | null>(null)
  const [deleting,     setDeleting]     = useState(false)
  const [assignJob,    setAssignJob]    = useState<Job | null>(null)

  const searchTimer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const fetchId     = useRef(0)

  // Keyboard shortcuts
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return
      if (e.key === "c") { e.preventDefault(); setCreateOpen(true) }
      if (e.key === "/") { e.preventDefault(); document.getElementById("jobs-search")?.focus() }
    }
    window.addEventListener("keydown", handler)
    return () => window.removeEventListener("keydown", handler)
  }, [])

  // Load active hold client IDs once on mount so we can show indicators in rows
  useEffect(() => {
    fetch("/api/hold-list")
      .then(r => r.json() as Promise<{ holds: { clientId: string }[] }>)
      .then(d => setHoldClientIds(new Set(d.holds.map(h => h.clientId))))
      .catch(() => {})
  }, [])

  // Load distinct designer names once on mount so the inline assign picker can offer
  // one-click reassignment to anyone who's already worked a job, no retyping.
  useEffect(() => {
    fetch("/api/jobs/designers")
      .then(r => r.json() as Promise<{ designers: string[] }>)
      .then(d => setDesigners(d.designers))
      .catch(() => {})
  }, [])

  const doFetch = useCallback(async (opts: {
    page: number; search: string; statusFilter: string; itemTypeFilter?: string; typeOfWorksFilter?: string; deadlineFilter?: string; sortBy: SortField; sortDir: SortDir; onlyOriginals?: boolean; onlyRevisions?: boolean
  }) => {
    const thisId = ++fetchId.current
    setLoading(true)
    const qs = new URLSearchParams({
      page: String(opts.page), limit: String(LIMIT),
      sortBy: opts.sortBy, sortDir: opts.sortDir,
      ...(opts.search                  && { search: opts.search }),
      ...(opts.statusFilter !== "ALL"  && { status: opts.statusFilter }),
      ...(opts.onlyOriginals && { onlyOriginals: "true" }),
      ...(opts.onlyRevisions && { onlyRevisions: "true" }),
      ...(opts.itemTypeFilter && opts.itemTypeFilter !== "ALL" && { itemType: opts.itemTypeFilter }),
      ...(opts.typeOfWorksFilter && opts.typeOfWorksFilter !== "ALL" && { typeOfWorks: opts.typeOfWorksFilter }),
      ...(opts.deadlineFilter === "overdue"     && { overdue: "true" }),
      ...(opts.deadlineFilter === "today"       && { dueToday: "true" }),
      ...(opts.deadlineFilter === "this_week"   && { dueThisWeek: "true" }),
    })
    try {
      const res = await fetch(`/api/jobs?${qs}`)
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const json = await res.json() as JobsResponse
      if (thisId === fetchId.current) setData(json)
    } catch (err) {
      if (thisId === fetchId.current) { console.error(err); toast("Failed to load jobs", "error") }
    } finally {
      if (thisId === fetchId.current) setLoading(false)
    }
  }, [toast])

  const refresh = useCallback(() =>
    doFetch({ page, search, statusFilter, itemTypeFilter, typeOfWorksFilter, deadlineFilter, sortBy, sortDir, onlyOriginals, onlyRevisions }),
    [doFetch, page, search, statusFilter, itemTypeFilter, typeOfWorksFilter, deadlineFilter, sortBy, sortDir, onlyOriginals, onlyRevisions]
  )

  useEffect(() => {
    doFetch({ page, search, statusFilter, itemTypeFilter, typeOfWorksFilter, deadlineFilter, sortBy, sortDir, onlyOriginals, onlyRevisions })
    // search is excluded deliberately — it has its own debounced effect below.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page, sortBy, sortDir, statusFilter, itemTypeFilter, typeOfWorksFilter, deadlineFilter, onlyOriginals, onlyRevisions])

  useEffect(() => {
    if (searchTimer.current) clearTimeout(searchTimer.current)
    searchTimer.current = setTimeout(() => {
      setPage(1)
      doFetch({ page: 1, search, statusFilter, itemTypeFilter, typeOfWorksFilter, deadlineFilter, sortBy, sortDir, onlyOriginals, onlyRevisions })
    }, 280)
    return () => { if (searchTimer.current) clearTimeout(searchTimer.current) }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search])

  const handleSort = (field: SortField) => {
    const dir: SortDir = sortBy === field && sortDir === "desc" ? "asc" : "desc"
    setSortBy(field); setSortDir(dir); setPage(1)
  }

  const handleCreate = async (form: JobFormData) => {
    setCreateSaving(true)
    try {
      const res = await fetch("/api/jobs", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, changedBy: userName }),
      })
      if (!res.ok) {
        const body = await res.json().catch(() => ({})) as { error?: string }
        toast(body.error ?? "Failed to create job", "error"); throw new Error()
      }
      const job = await res.json() as Job
      toast(`${job.drawingNumber} created`, "success")
      setCreateOpen(false); setPage(1)
      doFetch({ page: 1, search, statusFilter, itemTypeFilter, typeOfWorksFilter, deadlineFilter, sortBy, sortDir, onlyOriginals, onlyRevisions })
    } finally { setCreateSaving(false) }
  }

  const handleEdit = async (form: JobFormData) => {
    if (!editJob) return
    setEditSaving(true)
    try {
      const res = await fetch(`/api/jobs/${editJob.id}`, {
        method: "PATCH", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, changedBy: userName }),
      })
      if (!res.ok) { toast("Failed to save changes", "error"); throw new Error() }
      toast("Changes saved", "success")
      setEditJob(null); refresh()
    } finally { setEditSaving(false) }
  }

  const handleDelete = async () => {
    if (!deleteJob) return
    setDeleting(true)
    try {
      const res = await fetch(`/api/jobs/${deleteJob.id}`, { method: "DELETE" })
      if (!res.ok) { toast("Failed to delete job", "error"); return }
      toast(`${deleteJob.drawingNumber} deleted`, "info")
      setDeleteJob(null); setPage(1)
      doFetch({ page: 1, search, statusFilter, itemTypeFilter, typeOfWorksFilter, deadlineFilter, sortBy, sortDir, onlyOriginals, onlyRevisions })
    } finally { setDeleting(false) }
  }

  // Patches a single field on a job and updates the row in place — no full refetch, no modal.
  const patchJobField = async (job: Job, field: "status" | "designer", value: string) => {
    setData(prev => prev ? { ...prev, jobs: prev.jobs.map(j => j.id === job.id ? { ...j, [field]: value } : j) } : prev)
    try {
      const res = await fetch(`/api/jobs/${job.id}`, {
        method: "PATCH", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ [field]: value, changedBy: userName }),
      })
      if (!res.ok) {
        toast(field === "status" ? "Failed to change status" : "Failed to assign designer", "error")
        refresh() // roll back the optimistic update with the real server state
        return
      }
      const updated = await res.json() as Job
      setData(prev => prev ? { ...prev, jobs: prev.jobs.map(j => j.id === job.id ? updated : j) } : prev)
      if (field === "designer") {
        setDesigners(prev => value && !prev.includes(value) ? [...prev, value].sort() : prev)
      }
    } catch {
      toast("Network error", "error")
      refresh()
    }
  }

  // One-click revision — no modal, no fields. Letter is auto-assigned server-side.
  const handleQuickRevision = async (job: Job) => {
    try {
      const res = await fetch(`/api/jobs/${job.id}/revisions`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ changedBy: userName }),
      })
      if (!res.ok) {
        const body = await res.json().catch(() => ({})) as { error?: string }
        toast(body.error ?? "Failed to create revision", "error"); return
      }
      const revision = await res.json() as Job
      toast(`${revision.drawingNumber} created`, "success")
      refresh()
    } catch { toast("Network error", "error") }
  }

  const handleExport = async () => {
    const qs = new URLSearchParams({
      export: "true",
      ...(search                  && { search }),
      ...(statusFilter !== "ALL"  && { status: statusFilter }),
      ...(itemTypeFilter && itemTypeFilter !== "ALL" && { itemType: itemTypeFilter }),
      ...(typeOfWorksFilter && typeOfWorksFilter !== "ALL" && { typeOfWorks: typeOfWorksFilter }),
      ...(deadlineFilter === "overdue"   && { overdue: "true" }),
      ...(deadlineFilter === "today"     && { dueToday: "true" }),
      ...(deadlineFilter === "this_week" && { dueThisWeek: "true" }),
      ...(onlyOriginals && { onlyOriginals: "true" }),
      ...(onlyRevisions && { onlyRevisions: "true" }),
    })
    try {
      const { jobs } = await fetch(`/api/jobs?${qs}`).then(r => r.json()) as { jobs: Job[] }
      const headers = ["Drawing No.","Address","Type of Works","Custom Type Description","Client","Requested By","Item Type","Status","Designer","Quote Value","Quote Ref","Date Created","Date Completed","Originally Entered As","Notes"]
      const rows = jobs.map(j => [
        j.drawingNumber, j.address, j.typeOfWorks, j.customTypeDescription ?? "", j.clientCompany, j.requestedBy,
        j.itemType ?? "DESIGN", getJobStatus(j.status).label, j.designer,
        j.quoteValue != null ? j.quoteValue.toString() : "",
        j.quoteReference ?? "",
        format(new Date(j.dateCreated), "dd/MM/yyyy"),
        j.dateCompleted ? format(parseLocalDate(j.dateCompleted), "dd/MM/yyyy") : "",
        j.legacyTypeOfWorks ?? "",
        j.notes ?? "",
      ].map(v => `"${String(v).replace(/"/g,'""')}"`).join(","))
      const csv = [headers.join(","), ...rows].join("\n")
      const url = URL.createObjectURL(new Blob([csv], { type: "text/csv" }))
      const a = document.createElement("a")
      a.href = url; a.download = `oryx-jobs-${format(new Date(), "yyyy-MM-dd")}.csv`; a.click()
      URL.revokeObjectURL(url)
      toast(`Exported ${jobs.length} job${jobs.length !== 1 ? "s" : ""}`, "success")
    } catch { toast("Export failed", "error") }
  }

  const hasFilters = !!search || statusFilter !== "ALL" || itemTypeFilter !== "ALL" || typeOfWorksFilter !== "ALL" || deadlineFilter !== "ALL" || onlyOriginals || onlyRevisions
  const totalPages = data ? Math.ceil(data.total / LIMIT) : 0
  const sp = { current: sortBy, dir: sortDir, onSort: handleSort }

  return (
    <>
      {/* Toolbar */}
      <div className="flex items-center gap-2 mb-4 flex-wrap">
        <div className="relative flex-1 min-w-48 max-w-72">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-t4 pointer-events-none" />
          <Input
            id="jobs-search"
            value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Search jobs…" className="pl-8 pr-7"
          />
          {search && (
            <button onClick={() => setSearch("")} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-t4 hover:text-t2">
              <X className="h-3.5 w-3.5" />
            </button>
          )}
        </div>

        <Button
          variant={showFilters ? "secondary" : "outline"} size="sm"
          onClick={() => setShowFilters(v => !v)}
        >
          <SlidersHorizontal className="h-3.5 w-3.5" />
          Filter
          {statusFilter !== "ALL" && (
            <span className="ml-1 bg-ac text-sr rounded-full h-4 w-4 text-[10px] flex items-center justify-center font-bold shrink-0">1</span>
          )}
        </Button>

        <Button variant="outline" size="sm" onClick={handleExport}>
          <Download className="h-3.5 w-3.5" />
          Export
        </Button>

        <Button variant="primary" size="sm" className="ml-auto" onClick={() => setCreateOpen(true)}>
          <Plus className="h-3.5 w-3.5" />
          New job
        </Button>
      </div>

      {/* Filter bar */}
      {showFilters && (
        <div className="flex items-center gap-3 mb-4 px-3 py-2.5 bg-pg border border-bd rounded-md flex-wrap">
          <span className="text-xs font-medium text-t2">Status</span>
          <div className="w-44">
            <Select value={statusFilter} onValueChange={v => { setStatusFilter(v); setPage(1) }}>
              <SelectTrigger className="h-7 text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All statuses</SelectItem>
                {JOB_STATUSES.map(s => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          {/* Type of Works — a Select rather than pills, unlike item type below:
              18 controlled values would overwhelm a pill row at this width. */}
          <div className="h-4 w-px bg-bd" />
          <span className="text-xs font-medium text-t2">Type of Works</span>
          <div className="w-48">
            <Select value={typeOfWorksFilter} onValueChange={v => { setTypeOfWorksFilter(v); setPage(1) }}>
              <SelectTrigger className="h-7 text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All types of works</SelectItem>
                {WORKS_TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          {/* Work item type */}
          <div className="h-4 w-px bg-bd" />
          <span className="text-xs font-medium text-t2">Type</span>
          <div className="flex items-center gap-1 flex-wrap">
            <button onClick={() => { setItemTypeFilter("ALL"); setPage(1) }}
              className={`text-[11px] px-2.5 py-0.5 rounded-full font-medium ${itemTypeFilter === "ALL" ? "bg-ac text-sr" : "border border-bd text-t3 hover:text-t2"}`}>
              All
            </button>
            {WORK_ITEM_TYPES.map(t => (
              <button key={t.value} onClick={() => { setItemTypeFilter(t.value); setPage(1) }}
                className={`text-[11px] px-2.5 py-0.5 rounded-full font-medium ${itemTypeFilter === t.value ? `${t.color}` : "border border-bd text-t3 hover:text-t2"}`}>
                {t.label}
              </button>
            ))}
          </div>

          {/* Deadline filter */}
          <div className="h-4 w-px bg-bd" />
          <span className="text-xs font-medium text-t2">Deadline</span>
          <div className="flex items-center gap-1">
            {[
              { v: "ALL",       l: "All" },
              { v: "overdue",   l: "Overdue",   cls: "text-dn-tx bg-dn-bg" },
              { v: "today",     l: "Due today",  cls: "text-wn-tx bg-wn-bg" },
              { v: "this_week", l: "This week",  cls: "text-wn-tx bg-wn-bg/60" },
            ].map(({ v, l, cls }) => (
              <button key={v} onClick={() => { setDeadlineFilter(v); setPage(1) }}
                className={`text-[11px] px-2.5 py-0.5 rounded-full font-medium ${
                  deadlineFilter === v
                    ? (v === "ALL" ? "bg-ac text-sr" : (cls ?? "bg-ac text-sr"))
                    : "border border-bd text-t3 hover:text-t2"
                }`}>
                {l}
              </button>
            ))}
          </div>

          {hasFilters && (
            <button onClick={() => { setSearch(""); setStatusFilter("ALL"); setItemTypeFilter("ALL"); setTypeOfWorksFilter("ALL"); setDeadlineFilter("ALL"); setOnlyOriginals(false); setOnlyRevisions(false); setPage(1) }}
              className="text-xs text-t3 hover:text-t2 underline underline-offset-2">
              Clear all
            </button>
          )}
        </div>
      )}

      {/* Count */}
      {data && !loading && (
        <p className="text-xs text-t3 mb-3">
          <span className="font-semibold text-t2">{data.total.toLocaleString()}</span>
          {" "}job{data.total !== 1 ? "s" : ""}{hasFilters && " matching filters"}
        </p>
      )}

      {/* Table */}
      <div className="bg-sr border border-bd rounded-md overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-pg border-b border-bd">
                <SortTh field="drawingNumber" label="Drawing No." {...sp} />
                <SortTh field="address"       label="Address"     {...sp} />
                <th className={cn("px-4 py-2.5 text-left text-xs font-semibold text-t3 uppercase tracking-wider whitespace-nowrap", COL_TYPE_OF_WORKS)}>
                  Type of Works
                </th>
                <SortTh field="clientCompany" label="Client" className={COL_CLIENT} {...sp} />
                <th className={cn("px-4 py-2.5 text-left text-xs font-semibold text-t3 uppercase tracking-wider whitespace-nowrap", COL_REQUESTED_BY)}>
                  Requested By
                </th>
                <SortTh field="quoteValue" label="Quotation" className={COL_QUOTATION} {...sp} />
                <SortTh field="status"     label="Completion Status" {...sp} />
                <SortTh field="designer"   label="Designer" className={COL_DESIGNER} {...sp} />
                <th className="px-4 py-2.5 w-16" />
              </tr>
            </thead>
            <tbody>
              {loading ? <SkeletonRows /> :
               !data || data.jobs.length === 0 ? (
                <EmptyState hasFilters={hasFilters} onCreate={() => setCreateOpen(true)} onClear={() => { setSearch(""); setStatusFilter("ALL"); setItemTypeFilter("ALL"); setTypeOfWorksFilter("ALL"); setDeadlineFilter("ALL"); setOnlyOriginals(false); setOnlyRevisions(false); setPage(1) }} />
               ) : data.jobs.map(job => {
                const dl = getDeadlineInfo(job.requiredByDate)
                const showDeadlineFlag = dl.severity === "overdue" || dl.severity === "today" || dl.severity === "soon"
                return (
                <tr
                  key={job.id}
                  onClick={() => router.push(`/jobs/${job.id}`)}
                  className={cn(
                    "border-b border-bd last:border-0 cursor-pointer group",
                    // Subtle row tint by status — white for NEW_REQUEST, tinted for others
                    JOB_ROW_BG[job.status] ?? "",
                    // Hover brightens slightly — use white so tint doesn't conflict
                    "hover:brightness-95",
                  )}
                >
                  {/* Drawing No. — most prominent column; carries the revision marker and a
                      compact item-type indicator (Site Visit/Survey/Inspection/Revision) so
                      that information isn't lost now it's no longer its own column. Nothing
                      shown for plain Design jobs, the common case, to keep the cell quiet. */}
                  <td className="px-4 py-3.5 whitespace-nowrap">
                    <span className="flex items-center gap-1.5">
                      {job.revisionLetter && (
                        <span title={`Revision ${job.revisionLetter}`}><GitBranch className="h-3 w-3 text-ac shrink-0" aria-hidden /></span>
                      )}
                      <span className="font-mono text-[11px] font-semibold text-ac">{job.drawingNumber}</span>
                      {job.itemType && job.itemType !== "DESIGN" && job.itemType !== "REVISION" && (
                        <WorkItemTypeBadge itemType={job.itemType} size="sm" />
                      )}
                    </span>
                  </td>

                  {/* Address — truncated with a native title tooltip for the full text */}
                  <td className="px-4 py-3.5 max-w-[220px]">
                    <p className="text-sm font-medium text-t1 truncate" title={job.address}>{job.address}</p>
                  </td>

                  {/* Type of Works — controlled-list badge */}
                  <td className={cn("px-4 py-3.5 whitespace-nowrap", COL_TYPE_OF_WORKS)}>
                    <TypeOfWorksBadge typeOfWorks={job.typeOfWorks} customTypeDescription={job.customTypeDescription} size="sm" />
                  </td>

                  {/* Client — hold warning folded in here rather than a separate column */}
                  <td className={cn("px-4 py-3.5 max-w-[170px]", COL_CLIENT)}>
                    <div className="flex items-center gap-1.5 flex-wrap">
                      {job.clientId && holdClientIds.has(job.clientId) && (
                        <span title="Client on hold"><AlertTriangle className="h-3 w-3 text-dn shrink-0" /></span>
                      )}
                      <p className="text-xs font-medium text-t1 truncate">{job.clientCompany}</p>
                      {job.clientId && holdClientIds.has(job.clientId) && (
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-dn-bg text-dn-tx whitespace-nowrap">
                          On Hold
                        </span>
                      )}
                    </div>
                  </td>

                  {/* Requested By — who asked for the work; static text (not editable inline),
                      visually distinct from Designer below via a muted "who asked" person icon
                      so the two roles can't be confused at a glance. */}
                  <td className={cn("px-4 py-3.5 max-w-[150px]", COL_REQUESTED_BY)}>
                    <p className="text-xs text-t3 truncate flex items-center gap-1.5">
                      <UserCircle2 className="h-3 w-3 text-t4 shrink-0" />
                      {job.requestedBy || <span className="italic text-t4">—</span>}
                    </p>
                  </td>

                  {/* Quotation — value (existing behaviour) plus reference, stacked */}
                  <td className={cn("px-4 py-3.5 whitespace-nowrap text-right", COL_QUOTATION)}>
                    <p className="text-xs tabular-nums font-medium text-t2">
                      {job.quoteValue != null ? formatGBP(job.quoteValue) : <span className="text-t4">—</span>}
                    </p>
                    {job.quoteReference && (
                      <p className="text-[10px] font-mono text-t4 tabular-nums">{job.quoteReference}</p>
                    )}
                  </td>

                  {/* Completion Status — the visually dominant column. A deadline flag is
                      folded in directly underneath, only when overdue/due today/due soon —
                      this is the one place deadline urgency still surfaces in the table now
                      that Created/Deadline are no longer separate columns. */}
                  <td className="px-4 py-3.5 whitespace-nowrap" onClick={e => e.stopPropagation()}>
                    <InlineStatusSelect
                      status={job.status}
                      onChange={value => patchJobField(job, "status", value)}
                      size="lg"
                    />
                    {showDeadlineFlag && (
                      <p className={cn(
                        "mt-1 inline-flex items-center gap-1 text-[10px] font-medium",
                        dl.severity === "overdue" ? "text-dn-tx" : "text-wn-tx",
                      )}>
                        {dl.severity === "overdue" && <Clock className="h-2.5 w-2.5 shrink-0" />}
                        {dl.label}
                      </p>
                    )}
                  </td>

                  {/* Designer — who completed/is responsible for the design; the inline select
                      keeps a distinct "PenTool" icon so it reads as the "who did the work" role,
                      contrasting with Requested By's UserCircle2 "who asked" icon above. */}
                  <td className={cn("px-4 py-3.5 whitespace-nowrap", COL_DESIGNER)} onClick={e => e.stopPropagation()}>
                    <div className="flex items-center gap-1.5">
                      <PenTool className="h-3 w-3 text-t4 shrink-0" />
                      <InlineDesignerSelect
                        designer={job.designer}
                        designers={designers}
                        onChange={value => patchJobField(job, "designer", value)}
                        onRequestNew={() => setAssignJob(job)}
                      />
                    </div>
                  </td>

                  <td className="px-3 py-3.5" onClick={e => e.stopPropagation()}>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <button
                          className={cn(
                            "h-7 w-7 rounded flex items-center justify-center text-t4 hover:text-t2 hover:bg-pg",
                            "invisible group-hover:visible data-[state=open]:visible data-[state=open]:bg-pg data-[state=open]:text-t2",
                          )}
                          title="Quick actions"
                        >
                          <MoreHorizontal className="h-3.5 w-3.5" />
                        </button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onSelect={() => setEditJob(job)}>
                          <Pencil className="h-3.5 w-3.5 text-t4" /> Edit job
                        </DropdownMenuItem>
                        {!job.parentJobId && (
                          <DropdownMenuItem onSelect={() => handleQuickRevision(job)}>
                            <GitBranch className="h-3.5 w-3.5 text-t4" /> Create revision
                          </DropdownMenuItem>
                        )}
                        {job.clientId && (
                          <DropdownMenuItem onSelect={() => router.push(`/clients/${job.clientId}`)}>
                            <Building2 className="h-3.5 w-3.5 text-t4" /> View client
                          </DropdownMenuItem>
                        )}
                        {job.quoteReference && (
                          <DropdownMenuItem onSelect={() => router.push(`/quotes?search=${encodeURIComponent(job.quoteReference!)}`)}>
                            <FileText className="h-3.5 w-3.5 text-t4" /> Open quote
                          </DropdownMenuItem>
                        )}
                        <DropdownMenuSeparator />
                        <DropdownMenuItem danger onSelect={() => setDeleteJob(job)}>
                          <Trash2 className="h-3.5 w-3.5" /> Delete job
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </td>
                </tr>
              )})}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {data && totalPages > 1 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-bd bg-pg">
            <p className="text-xs text-t3">
              {((page - 1) * LIMIT) + 1}–{Math.min(page * LIMIT, data.total)} of{" "}
              <span className="font-semibold text-t2">{data.total.toLocaleString()}</span>
            </p>
            <div className="flex items-center gap-1">
              <Button variant="outline" size="icon-sm" onClick={() => setPage(p => p - 1)} disabled={page === 1}>
                <ChevronLeft className="h-3.5 w-3.5" />
              </Button>
              <span className="text-xs text-t2 px-2 tabular-nums min-w-[56px] text-center">
                {page} / {totalPages}
              </span>
              <Button variant="outline" size="icon-sm" onClick={() => setPage(p => p + 1)} disabled={page === totalPages}>
                <ChevronRight className="h-3.5 w-3.5" />
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Create dialog */}
      <Dialog open={createOpen} onOpenChange={o => { if (!createSaving) setCreateOpen(o) }}>
        <DialogContent size="lg">
          <DialogHeader>
            <DialogTitle>New job</DialogTitle>
            <DialogDescription>Drawing number assigned automatically on save.</DialogDescription>
          </DialogHeader>
          <DialogBody>
            <JobForm key={createOpen ? "open" : "closed"} formId="create-job-form" onSubmit={handleCreate} />
          </DialogBody>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateOpen(false)} disabled={createSaving}>Cancel</Button>
            <Button type="submit" form="create-job-form" variant="primary" loading={createSaving} disabled={createSaving}>
              {createSaving ? "Creating…" : "Create job"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit dialog */}
      <Dialog open={!!editJob} onOpenChange={o => { if (!o && !editSaving) setEditJob(null) }}>
        <DialogContent size="lg">
          <DialogHeader>
            <DialogTitle>Edit job</DialogTitle>
            <DialogDescription>Update job details and status.</DialogDescription>
          </DialogHeader>
          <DialogBody>
            {editJob && <JobForm key={editJob.id} formId="edit-job-form" job={editJob} onSubmit={handleEdit} />}
          </DialogBody>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditJob(null)} disabled={editSaving}>Cancel</Button>
            <Button type="submit" form="edit-job-form" variant="primary" loading={editSaving} disabled={editSaving}>
              {editSaving ? "Saving…" : "Save changes"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete dialog */}
      <Dialog open={!!deleteJob} onOpenChange={o => { if (!o && !deleting) setDeleteJob(null) }}>
        <DialogContent size="sm">
          <DialogHeader>
            <DialogTitle>Delete job</DialogTitle>
            <DialogDescription>
              Permanently delete{" "}
              <span className="font-mono font-semibold text-ac">{deleteJob?.drawingNumber}</span>?
              This cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteJob(null)} disabled={deleting}>Cancel</Button>
            <Button variant="danger" onClick={handleDelete} loading={deleting} disabled={deleting}>
              {deleting ? "Deleting…" : "Delete job"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      {/* Assign designer modal — fallback for entering a brand-new name not yet in the inline picker */}
      <AssignDesignerModal
        job={assignJob}
        onClose={() => setAssignJob(null)}
        onSaved={updated => {
          setAssignJob(null)
          setData(prev => prev ? {
            ...prev,
            jobs: prev.jobs.map(j => j.id === updated.id ? updated : j),
          } : prev)
          setDesigners(prev => updated.designer && !prev.includes(updated.designer)
            ? [...prev, updated.designer].sort() : prev)
        }}
      />
    </>
  )
}
