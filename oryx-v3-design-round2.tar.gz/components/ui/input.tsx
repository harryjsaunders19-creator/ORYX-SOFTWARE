import * as React from "react"
import { cn } from "@/lib/utils"

const Input = React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement>>(
  ({ className, type, style, ...props }, ref) => (
    <input
      type={type}
      ref={ref}
      className={cn(
        "flex h-9 w-full rounded-lg border border-bd bg-sr px-3.5 text-sm text-t1",
        "placeholder:text-t4",
        "focus:outline-none focus:ring-2 focus:ring-ac/20 focus:border-ac",
        "disabled:cursor-not-allowed disabled:opacity-50 disabled:bg-pg",
        className,
      )}
      style={{
        // Inline styles ensure inputs are always visible regardless of Tailwind output
        height: "36px",
        width: "100%",
        borderRadius: "8px",
        border: "1px solid #EDEBE9",
        backgroundColor: "#ffffff",
        paddingLeft: "14px",
        paddingRight: "14px",
        fontSize: "14px",
        color: "#18181B",
        outline: "none",
        ...style,
      }}
      {...props}
    />
  )
)
Input.displayName = "Input"
export { Input }
