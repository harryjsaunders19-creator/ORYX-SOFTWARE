"use client"
import { useEffect, useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  LayoutDashboard, FolderOpen, Activity, Receipt,
  Building2, AlertTriangle, FileText, Users as UsersIcon, ShieldCheck, DatabaseBackup,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { useUser } from "@/components/user-context"
import { modulesForRole } from "@/lib/permissions"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"

// Icons live here (not in lib/permissions.ts) so that file stays framework-agnostic.
const ICONS: Record<string, React.ElementType> = {
  dashboard:  LayoutDashboard,
  clients:    Building2,
  "hold-list": AlertTriangle,
  jobs:       FolderOpen,
  quotes:     FileText,
  billing:    Receipt,
  users:      UsersIcon,
  backups:    DatabaseBackup,
  health:     Activity,
}

// Sub-paths under a module's main href that should still count as "active"
const ACTIVE_PREFIX: Record<string, boolean> = {
  "hold-list": true, billing: true,
}

// The sidebar is the one place in the UI that's intentionally dark — the ink
// half of the monochrome identity lives here permanently, so the light
// content area can stay airy. These are one-off literal values rather than
// design-system tokens, because the rest of the app has no dark surfaces and
// these colours only make sense in this dark context.
const SIDEBAR_BG     = "#1C1C1E"   /* v3: Apple's iOS "system gray 6 dark" — same intent as the previous #18181B, just the real Apple near-black rather than Tailwind's zinc-900 */
const SIDEBAR_BORDER = "rgba(255, 255, 255, 0.08)"
const SIDEBAR_TEXT   = "#A1A1AA"
const SIDEBAR_TEXT_ACTIVE = "#FFFFFF"
const SIDEBAR_TINT_ACTIVE = "rgba(70, 64, 222, 0.18)"   // ac at low opacity
const SIDEBAR_AVATAR_BG   = "#2A2A2E"

function UserSwitcher() {
  const { user, role, isAdmin, isImpersonating, realUser, switchUser, exitImpersonation, logout } = useUser()
  const [people, setPeople] = useState<{ id: string; name: string; role: string }[]>([])
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    if (user && !isAdmin) return   // dropdown isn't shown in this case — no need to fetch the list at all
    fetch("/api/auth/users")
      .then(r => r.json() as Promise<{ users: typeof people }>)
      .then(d => setPeople(d.users))
      .catch(() => {})
  }, [user, isAdmin])

  const handleSwitch = async (userId: string) => {
    setError(null); setBusy(true)
    try { await switchUser(userId) }
    catch (e) { setError(e instanceof Error ? e.message : "Could not switch identity") }
    finally { setBusy(false) }
  }

  const handleExit = async () => {
    setBusy(true)
    try { await exitImpersonation() } catch { /* surfaced via the unchanged banner if it somehow fails */ }
    finally { setBusy(false) }
  }

  return (
    <div className="px-3 py-3 shrink-0" style={{ padding: "12px", borderTop: `1px solid ${SIDEBAR_BORDER}` }}>
      {isImpersonating && realUser && (
        <div
          className="mb-2 px-2 py-1.5 rounded text-[11px] leading-snug"
          style={{ backgroundColor: "rgba(127, 119, 221, 0.18)", color: SIDEBAR_TEXT_ACTIVE }}
        >
          <p className="font-medium">Acting as {user?.name}</p>
          <p style={{ color: SIDEBAR_TEXT }}>Signed in as {realUser.name} (admin)</p>
          <button onClick={handleExit} disabled={busy} className="mt-1 underline" style={{ color: SIDEBAR_TEXT_ACTIVE }}>
            Exit — return to {realUser.name}
          </button>
        </div>
      )}
      <div className="flex items-center gap-2 mb-2 px-1">
        <div
          className="w-6 h-6 rounded-full flex items-center justify-center shrink-0"
          style={{ width: "24px", height: "24px", borderRadius: "9999px", backgroundColor: SIDEBAR_AVATAR_BG, display: "flex", alignItems: "center", justifyContent: "center" }}
        >
          <ShieldCheck className="h-3.5 w-3.5" style={{ color: role === "ADMIN" ? "#7F77DD" : SIDEBAR_TEXT }} />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-xs font-semibold truncate" style={{ color: SIDEBAR_TEXT_ACTIVE, fontWeight: 600 }}>{user?.name ?? "No identity selected"}</p>
          <p className="text-[10px]" style={{ color: SIDEBAR_TEXT }}>{role === "ADMIN" ? "Admin" : "Engineer"}</p>
        </div>
      </div>

      {/* The switcher is available in two cases: nobody has signed in yet for
          this browser session at all (cold start — anyone can pick who they
          are, since there's no credential to check it against), or an admin
          who's already signed in as themselves wanting to impersonate someone
          else. What's deliberately NOT offered is a non-admin who's already
          signed in switching to a *different* identity — the backend would
          reject that anyway, and showing a dropdown of options that always
          fail is confusing UX, not real protection. That person must log out
          and sign in as the other identity from a cold start instead. */}
      {(!user || (isAdmin && !isImpersonating)) && (
        <Select value={user?.id ?? ""} onValueChange={handleSwitch}>
          <SelectTrigger><SelectValue placeholder="Switch user…" /></SelectTrigger>
          <SelectContent>
            {people.map(p => (
              <SelectItem key={p.id} value={p.id}>
                {p.name} · {p.role === "ADMIN" ? "Admin" : "Engineer"}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      )}
      {error && <p className="text-[10px] mt-1.5" style={{ color: "#F5A3A3" }}>{error}</p>}

      {user && (
        <button onClick={() => logout()} className="text-[11px] mt-2 underline" style={{ color: SIDEBAR_TEXT }}>
          Log out
        </button>
      )}
      <p className="text-[10px] mt-2 leading-snug" style={{ color: SIDEBAR_TEXT }}>
        {!user
          ? "Pick who you are to continue."
          : isAdmin
            ? "Switching to another account is logged and restricted to administrators."
            : "Only administrators can switch accounts. Log out to sign in as someone else."}
      </p>
    </div>
  )
}

export function SideNav() {
  const path = usePathname()
  const { role } = useUser()
  const nav = modulesForRole(role)

  return (
    <aside
      className={cn(
        "w-52 shrink-0 flex flex-col h-full",
        // z-10 keeps sidebar below modal backdrop (z-[100])
        // isolate prevents any child from escaping this stacking context
        "relative z-10 isolate",
      )}
      style={{
        width: "208px",
        flexShrink: 0,
        display: "flex",
        flexDirection: "column",
        height: "100%",
        backgroundColor: SIDEBAR_BG,
        borderRight: `1px solid ${SIDEBAR_BORDER}`,
        position: "relative",
        zIndex: 10,
        isolation: "isolate",
      }}
    >
      {/* Logo */}
      <div
        className="h-14 px-4 flex items-center gap-3 shrink-0"
        style={{ height: "56px", padding: "0 16px", display: "flex", alignItems: "center", gap: "12px", borderBottom: `1px solid ${SIDEBAR_BORDER}`, flexShrink: 0 }}
      >
        <div
          className="w-7 h-7 rounded bg-ac flex items-center justify-center shrink-0"
          style={{ width: "28px", height: "28px", borderRadius: "6px", backgroundColor: "#4640DE", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}
        >
          <span className="font-mono font-bold text-xs leading-none" style={{ fontFamily: "monospace", fontWeight: 700, fontSize: "12px", color: "#ffffff", lineHeight: 1 }}>Ox</span>
        </div>
        <span className="text-sm font-semibold" style={{ fontSize: "14px", fontWeight: 600, color: SIDEBAR_TEXT_ACTIVE, letterSpacing: "0.01em" }}>Oryx Design</span>
      </div>

      {/* Navigation — filtered to modules the current role can access (lib/permissions.ts) */}
      <nav className="flex-1 px-2 py-3 space-y-px" style={{ flex: 1, padding: "12px 8px", display: "flex", flexDirection: "column", gap: "2px" }}>
        {nav.map(({ key, href, label }) => {
          const Icon = ICONS[key] ?? FolderOpen
          const active = ACTIVE_PREFIX[key] ? path.startsWith(href) : path === href
          return (
            <Link
              key={href}
              href={href}
              className="flex items-center gap-2.5 px-3 py-2.5 text-[13px] outline-none focus-visible:ring-2 focus-visible:ring-ac focus-visible:ring-inset"
              style={{
                display: "flex",
                alignItems: "center",
                gap: "10px",
                padding: "9px 12px 9px 9px",
                borderRadius: "8px",
                borderLeft: active ? "3px solid #4640DE" : "3px solid transparent",
                fontSize: "13px",
                fontWeight: active ? 600 : 500,
                textDecoration: "none",
                backgroundColor: active ? SIDEBAR_TINT_ACTIVE : "transparent",
                color: active ? SIDEBAR_TEXT_ACTIVE : SIDEBAR_TEXT,
              }}
            >
              <Icon
                className="h-4 w-4 shrink-0"
                style={{ width: "16px", height: "16px", flexShrink: 0, color: active ? "#7F77DD" : SIDEBAR_TEXT }}
              />
              {label}
            </Link>
          )
        })}
      </nav>

      <UserSwitcher />

      {/* Footer */}
      <div
        className="px-4 py-3 shrink-0"
        style={{ padding: "12px 16px", borderTop: `1px solid ${SIDEBAR_BORDER}`, flexShrink: 0 }}
      >
        <p style={{ fontSize: "11px", color: SIDEBAR_TEXT }}>Oryx Design Ltd · 2026</p>
      </div>
    </aside>
  )
}
