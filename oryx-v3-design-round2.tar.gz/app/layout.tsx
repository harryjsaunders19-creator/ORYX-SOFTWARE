import type { Metadata } from "next"
import "@fontsource/inter/400.css"
import "@fontsource/inter/500.css"
import "@fontsource/inter/600.css"
import "@fontsource/jetbrains-mono/500.css"
import "./globals.css"
import { SideNav }       from "@/components/side-nav"
import { ToastProvider } from "@/components/ui/toast"
import { UserProvider }  from "@/components/user-context"

export const metadata: Metadata = {
  title: { default: "Oryx Design", template: "%s · Oryx" },
  description: "Scaffold design job management",
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body style={{ height: "100%", margin: 0, backgroundColor: "#FAFAF9" }}>
        <UserProvider>
          <ToastProvider>
            {/*
             * Z-index contract:
             *   sidebar:        z-10   (relative + isolate, stacking context confined)
             *   modal backdrop: z-[100] (via DialogPortal → document.body)
             *   modal panel:    z-[101] (via DialogPortal → document.body)
             *   toasts:         z-[200] (via document.body)
             *
             * The DialogPortal renders directly into document.body, so the modal
             * is never a child of the sidebar and always appears above it.
             */}
            <div
              className="flex h-screen overflow-hidden bg-pg"
              style={{ display: "flex", height: "100vh", overflow: "hidden", backgroundColor: "#FAFAF9" }}
            >
              <SideNav />
              <main
                className="relative z-0 isolate flex-1 overflow-y-auto thin-scroll bg-pg"
                style={{ position: "relative", zIndex: 0, isolation: "isolate", flex: 1, overflowY: "auto", backgroundColor: "#FAFAF9" }}
              >
                <div
                  className="max-w-[1400px] mx-auto"
                  style={{ maxWidth: "1400px", margin: "0 auto" }}
                >
                  {children}
                </div>
              </main>
            </div>
          </ToastProvider>
        </UserProvider>
      </body>
    </html>
  )
}
