"use client"
import { useEffect, useState } from "react"
import { useParams, useRouter } from "next/navigation"
import Link from "next/link"
import { format } from "date-fns"
import { ArrowLeft, Building2, Mail, Phone, MapPin, FileText, AlertTriangle, ShieldOff } from "lucide-react"
import { Button }        from "@/components/ui/button"
import { StatusBadge }   from "@/components/status-badge"
import { WorkItemTypeBadge } from "@/components/work-item-type-badge"
import { useToast }      from "@/components/ui/toast"
import { formatGBP }     from "@/lib/utils"
import type { Client, ClientStats, ClientHold, Job } from "@/lib/types"

interface ClientDetail { client: Client; stats: ClientStats; jobs: Job[] }
import { useState as useHoldState } from "react"
import { Button as HoldButton } from "@/components/ui/button"
import { Input as HoldInput } from "@/components/ui/input"
import { Textarea as HoldTextarea } from "@/components/ui/textarea"
import { Label as HoldLabel } from "@/components/ui/label"
import { useUser as useHoldUser } from "@/components/user-context"
import { useToast as useHoldToast } from "@/components/ui/toast"

function StatCard({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="bg-sr border border-bd rounded-md p-3">
      <p className="text-[11px] font-medium text-t3 uppercase tracking-wider mb-1">{label}</p>
      <p className="text-xl font-semibold tabular-nums text-t1">{value}</p>
    </div>
  )
}

export default function ClientDetailPage() {
  const { id }     = useParams() as { id: string }
  const router     = useRouter()
  const { toast }  = useToast()
  const [detail,   setDetail]   = useState<ClientDetail | null>(null)
  const [loading,  setLoading]  = useState(true)
  const [notFound, setNotFound] = useState(false)
  const [hold,     setHold]     = useState<ClientHold | null>(null)
  const [holdSaving, setHoldSaving] = useState(false)
  const [holdOpen, setHoldOpen] = useState(false)
  const [holdReason, setHoldReason] = useState("")
  const [holdNotes, setHoldNotes] = useState("")
  const [removeOpen, setRemoveOpen] = useState(false)
  const [removeReason, setRemoveReason] = useState("")
  const { userName, isAdmin } = useHoldUser()
  const { toast: holdToast } = useHoldToast()

  useEffect(() => {
    Promise.all([
      fetch(`/api/clients/${id}`).then(r => {
        if (r.status === 404) { setNotFound(true); return null }
        return r.json() as Promise<ClientDetail>
      }),
      fetch(`/api/clients/${id}/hold`).then(r => r.json() as Promise<{ hold: ClientHold | null }>),
    ])
      .then(([detail, holdData]) => {
        if (detail) setDetail(detail)
        if (holdData?.hold) setHold(holdData.hold)
      })
      .catch(() => toast("Failed to load client", "error"))
      .finally(() => setLoading(false))
  }, [id]) // eslint-disable-line

  const addToHold = async () => {
    if (!holdReason.trim()) return
    setHoldSaving(true)
    try {
      const res = await fetch(`/api/clients/${id}/hold`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reason: holdReason.trim(), notes: holdNotes.trim() || null, addedBy: userName }),
      })
      if (!res.ok) { holdToast("Failed to add hold", "error"); return }
      const h = await res.json() as ClientHold
      setHold(h); setHoldOpen(false); setHoldReason(""); setHoldNotes("")
      holdToast("Client placed on hold", "info")
    } catch { holdToast("Network error", "error") }
    finally { setHoldSaving(false) }
  }

  const removeFromHold = async () => {
    setHoldSaving(true)
    try {
      const res = await fetch(`/api/clients/${id}/hold`, {
        method: "DELETE", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ removedBy: userName, removedReason: removeReason.trim() || null }),
      })
      if (!res.ok) { holdToast("Failed to remove hold", "error"); return }
      setHold(null); setRemoveOpen(false); setRemoveReason("")
      holdToast("Client removed from hold", "success")
    } catch { holdToast("Network error", "error") }
    finally { setHoldSaving(false) }
  }

  if (loading) return (
    <div className="px-6 py-6 max-w-4xl space-y-4">
      <div className="skeleton h-4 w-24 rounded" />
      <div className="skeleton h-7 w-64 rounded" />
      <div className="grid grid-cols-3 gap-3 mt-4">{[...Array(6)].map((_,i) => <div key={i} className="skeleton h-16 rounded" />)}</div>
    </div>
  )

  if (notFound || !detail) return (
    <div className="px-6 py-6 max-w-4xl text-center py-20">
      <p className="text-sm text-t3">Client not found.</p>
      <Link href="/clients" className="text-sm text-ac mt-3 inline-block">← Back to clients</Link>
    </div>
  )

  const { client, stats, jobs } = detail
  const designJobs     = jobs.filter(j => j.itemType === "DESIGN" || !j.itemType)
  const revisions      = jobs.filter(j => j.itemType === "REVISION")
  const nonDesignJobs  = jobs.filter(j => j.itemType && !["DESIGN","REVISION"].includes(j.itemType))

  return (
    <div className="px-6 py-6 max-w-4xl">
      <Link href="/clients" className="inline-flex items-center gap-1.5 text-xs text-t3 hover:text-t2 mb-4">
        <ArrowLeft className="h-3.5 w-3.5" /> All clients
      </Link>

      {/* Header */}
      <div className="flex items-start justify-between mb-5">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Building2 className="h-5 w-5 text-ac" />
            <h1 className="text-lg font-semibold text-t1">{client.name}</h1>
            {!client.active && (
              <span className="text-[11px] bg-t1/[0.06] text-t3 rounded-full px-2.5 py-0.5">Archived</span>
            )}
          </div>
          <div className="flex flex-wrap gap-4 text-xs text-t3">
            {client.contactName  && <span>{client.contactName}</span>}
            {client.email        && <a href={`mailto:${client.email}`} className="flex items-center gap-1 text-ac hover:text-ach"><Mail className="h-3 w-3" />{client.email}</a>}
            {client.phone        && <span className="flex items-center gap-1"><Phone className="h-3 w-3" />{client.phone}</span>}
            {client.billingAddress && <span className="flex items-center gap-1"><MapPin className="h-3 w-3" />{client.billingAddress}</span>}
          </div>
        </div>
        <Button variant="outline" size="sm" onClick={() => router.push(`/clients`)}>
          All clients
        </Button>
      </div>

      {/* Hold banner */}
      {hold && (
        <div className="rounded-xl border-2 border-dn overflow-hidden mb-5"
          style={{ border: "2px solid #F87171" }}>
          <div className="bg-dn px-4 py-3 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <AlertTriangle className="h-5 w-5 text-white shrink-0" />
              <div>
                <p className="font-bold text-white text-sm">CLIENT ON HOLD</p>
                <p className="text-white/85 text-xs">Added {hold.addedAt ? format(new Date(hold.addedAt), "d MMM yyyy") : ""} by {hold.addedBy}</p>
              </div>
            </div>
            <HoldButton variant="secondary" size="sm" onClick={() => setRemoveOpen(true)}
              style={{ backgroundColor: "rgba(255,255,255,0.15)", color: "#fff", border: "1px solid rgba(255,255,255,0.3)" }}>
              Remove hold
            </HoldButton>
          </div>
          <div className="bg-dn-bg px-4 py-3 border-t border-dn-bd space-y-1">
            <div className="flex gap-2">
              <span className="text-xs font-semibold text-dn uppercase tracking-wider w-16 shrink-0">Reason</span>
              <span className="text-sm text-dn-tx font-medium">{hold.reason}</span>
            </div>
            {hold.notes && (
              <div className="flex gap-2">
                <span className="text-xs font-semibold text-dn uppercase tracking-wider w-16 shrink-0">Notes</span>
                <span className="text-sm text-dn-tx">{hold.notes}</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Add to hold button (when not on hold) */}
      {!hold && (
        <div className="mb-5 flex justify-end">
          <HoldButton variant="outline" size="sm" onClick={() => setHoldOpen(true)}
            className="text-t3 hover:text-dn hover:border-dn-bd">
            <ShieldOff className="h-3.5 w-3.5" /> Place on hold
          </HoldButton>
        </div>
      )}

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 mb-5">
        <StatCard label="Total jobs"     value={stats.totalJobs}    />
        <StatCard label="Active"         value={stats.activeJobs}   />
        <StatCard label="Issued"         value={stats.issuedJobs}   />
        <StatCard label="Revisions"      value={stats.totalRevisions} />
        <StatCard label="Total quoted"   value={formatGBP(stats.totalQuotedValue)} />
        {isAdmin && <StatCard label="Total invoiced" value={formatGBP(stats.totalInvoicedValue)} />}
      </div>

      {/* Notes */}
      {client.notes && (
        <div className="bg-pg border border-bd rounded-md px-4 py-3 mb-5 flex gap-2">
          <FileText className="h-4 w-4 text-t4 shrink-0 mt-0.5" />
          <p className="text-xs text-t2">{client.notes}</p>
        </div>
      )}

      {/* Design jobs */}
      {designJobs.length > 0 && (
        <section className="mb-5">
          <h2 className="text-xs font-semibold text-t3 uppercase tracking-wider mb-2">Designs ({designJobs.length})</h2>
          <JobsTable jobs={designJobs} />
        </section>
      )}

      {/* Revisions */}
      {revisions.length > 0 && (
        <section className="mb-5">
          <h2 className="text-xs font-semibold text-t3 uppercase tracking-wider mb-2">Revisions ({revisions.length})</h2>
          <JobsTable jobs={revisions} />
        </section>
      )}

      {/* Site visits / surveys / inspections */}
      {nonDesignJobs.length > 0 && (
        <section className="mb-5">
          <h2 className="text-xs font-semibold text-t3 uppercase tracking-wider mb-2">Site visits & other ({nonDesignJobs.length})</h2>
          <JobsTable jobs={nonDesignJobs} />
        </section>
      )}

        {/* Add hold modal */}
      {holdOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center" style={{ backgroundColor: "rgba(0,0,0,0.45)" }}>
          <div className="bg-sr rounded-xl border border-bd shadow-modal w-[calc(100vw-2rem)] max-w-[400px] overflow-hidden"
            style={{ background: "#ffffff", border: "1px solid #E7E5E4" }}>
            <div className="px-5 pt-5 pb-3 border-b border-bd">
              <p className="font-semibold text-t1">Place client on hold</p>
              <p className="text-xs text-t3 mt-0.5">{detail?.client.name}</p>
            </div>
            <div className="px-5 py-4 space-y-3">
              <div className="flex flex-col gap-1.5">
                <HoldLabel>Reason *</HoldLabel>
                <HoldInput value={holdReason} onChange={e => setHoldReason(e.target.value)} autoFocus placeholder="e.g. Outstanding debt, dispute in progress" />
              </div>
              <div className="flex flex-col gap-1.5">
                <HoldLabel>Notes (optional)</HoldLabel>
                <HoldTextarea value={holdNotes} onChange={e => setHoldNotes(e.target.value)} rows={2} placeholder="Additional context…" />
              </div>
              <div className="flex gap-2 pt-1">
                <HoldButton variant="danger" onClick={addToHold} loading={holdSaving} disabled={!holdReason.trim()}>Place on hold</HoldButton>
                <HoldButton variant="outline" onClick={() => { setHoldOpen(false); setHoldReason(""); setHoldNotes("") }} disabled={holdSaving}>Cancel</HoldButton>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Remove hold modal */}
      {removeOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center" style={{ backgroundColor: "rgba(0,0,0,0.45)" }}>
          <div className="bg-sr rounded-xl border border-bd shadow-modal w-[calc(100vw-2rem)] max-w-[400px] overflow-hidden"
            style={{ background: "#ffffff", border: "1px solid #E7E5E4" }}>
            <div className="px-5 pt-5 pb-3 border-b border-bd">
              <p className="font-semibold text-t1">Remove from hold</p>
              <p className="text-xs text-t3 mt-0.5">{detail?.client.name}</p>
            </div>
            <div className="px-5 py-4 space-y-3">
              <div className="flex flex-col gap-1.5">
                <HoldLabel>Reason for removal (optional)</HoldLabel>
                <HoldInput value={removeReason} onChange={e => setRemoveReason(e.target.value)} autoFocus placeholder="e.g. Debt settled, issue resolved" />
              </div>
              <div className="flex gap-2 pt-1">
                <HoldButton variant="primary" onClick={removeFromHold} loading={holdSaving}>Remove from hold</HoldButton>
                <HoldButton variant="outline" onClick={() => { setRemoveOpen(false); setRemoveReason("") }} disabled={holdSaving}>Cancel</HoldButton>
              </div>
            </div>
          </div>
        </div>
      )}

    <p className="text-xs text-t4 mt-4">
        Client created {format(new Date(client.createdAt), "d MMMM yyyy")} ·
        Last updated {format(new Date(client.updatedAt), "d MMMM yyyy")}
      </p>
    </div>
  )
}

function JobsTable({ jobs }: { jobs: Job[] }) {
  return (
    <div className="bg-sr border border-bd rounded-md overflow-hidden">
      <table className="w-full text-sm">
        <thead>
          <tr className="bg-pg border-b border-bd text-xs">
            <th className="px-3 py-2 text-left font-semibold text-t3 uppercase tracking-wider">Drawing No.</th>
            <th className="px-3 py-2 text-left font-semibold text-t3 uppercase tracking-wider">Address</th>
            <th className="px-3 py-2 text-left font-semibold text-t3 uppercase tracking-wider">Completion Status</th>
            <th className="px-3 py-2 text-right font-semibold text-t3 uppercase tracking-wider">Quote</th>
          </tr>
        </thead>
        <tbody>
          {jobs.map(j => (
            <tr key={j.id} className="border-b border-bd last:border-0 hover:bg-pg">
              <td className="px-3 py-2.5 whitespace-nowrap">
                <span className="inline-flex items-center gap-1.5">
                  <Link href={`/jobs/${j.id}`} className="font-mono text-[11px] font-semibold text-ac hover:underline">
                    {j.drawingNumber}
                  </Link>
                  {j.itemType && j.itemType !== "DESIGN" && j.itemType !== "REVISION" && (
                    <WorkItemTypeBadge itemType={j.itemType} size="sm" />
                  )}
                </span>
              </td>
              <td className="px-3 py-2.5 text-xs text-t2 max-w-[200px] truncate" title={j.address}>{j.address}</td>
              <td className="px-3 py-2.5"><StatusBadge status={j.status} /></td>
              <td className="px-3 py-2.5 text-right text-xs text-t2 tabular-nums">
                {j.quoteValue != null ? formatGBP(j.quoteValue) : <span className="text-t4">—</span>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
