import { NextResponse } from "next/server"
import { getCurrentUser, getRealUser } from "@/lib/auth"

export async function GET() {
  try {
    const [user, realUser] = await Promise.all([getCurrentUser(), getRealUser()])
    const impersonating = !!user && !!realUser && user.id !== realUser.id
    return NextResponse.json({
      user,
      isImpersonating: impersonating,
      realUser: impersonating ? { id: realUser!.id, name: realUser!.name } : null,
    })
  } catch (err) {
    console.error("[GET /api/auth/session]", err)
    return NextResponse.json({ error: String(err) }, { status: 500 })
  }
}
