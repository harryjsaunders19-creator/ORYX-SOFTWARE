import { NextRequest, NextResponse } from "next/server"
import { clientDb } from "@/lib/db"
import { createId } from "@paralleldrive/cuid2"

export async function GET(req: NextRequest) {
  try {
    const sp         = req.nextUrl.searchParams
    const search     = sp.get("search")     ?? ""
    const activeOnly = sp.get("active")     !== "false"   // default: only active
    const page       = Math.max(1, parseInt(sp.get("page")  ?? "1"))
    const limit      = Math.max(1, Math.min(200, parseInt(sp.get("limit") ?? "50")))

    const clients = clientDb.findManyWithMeta({ search, activeOnly, skip: (page - 1) * limit, take: limit })
    const total   = clientDb.count({ search, activeOnly })
    return NextResponse.json({ clients, total, page, limit })
  } catch (err) {
    console.error("[GET /api/clients]", err)
    return NextResponse.json({ error: String(err) }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    let body: Record<string, unknown>
    try { body = await req.json() }
    catch { return NextResponse.json({ error: "Invalid JSON" }, { status: 400 }) }

    const name = typeof body.name === "string" ? body.name.trim() : ""
    if (!name) return NextResponse.json({ error: "Company name is required" }, { status: 422 })

    // Duplicate check
    const existing = clientDb.findByName(name)
    if (existing) {
      return NextResponse.json({
        error:    `A client named "${existing.name}" already exists.`,
        existing,
      }, { status: 409 })
    }

    const client = clientDb.create({
      id:             createId(),
      name,
      contactName:    body.contactName    ? String(body.contactName).trim()    : null,
      email:          body.email          ? String(body.email).trim()          : null,
      phone:          body.phone          ? String(body.phone).trim()          : null,
      billingAddress: body.billingAddress ? String(body.billingAddress).trim() : null,
      notes:          body.notes          ? String(body.notes).trim()          : null,
      accountCode:    body.accountCode    ? String(body.accountCode).trim()    : null,
    })
    return NextResponse.json(client, { status: 201 })
  } catch (err) {
    console.error("[POST /api/clients]", err)
    return NextResponse.json({ error: String(err) }, { status: 500 })
  }
}
