import { NextRequest, NextResponse } from "next/server"
import { clientDb } from "@/lib/db"
import { getCurrentRole } from "@/lib/auth"
import { canViewCommercialValues } from "@/lib/permissions"

type Ctx = { params: Promise<{ id: string }> }

export async function GET(_req: NextRequest, { params }: Ctx) {
  try {
    const { id } = await params
    const client = clientDb.findUnique(id)
    if (!client) return NextResponse.json({ error: "Not found" }, { status: 404 })
    const rawStats = clientDb.stats(id)
    const role = await getCurrentRole()
    // totalInvoicedValue is Invoicing/Revenue-Reports data (Admin-only — see lib/permissions.ts);
    // totalQuotedValue is Quotes-derived and not commercially restricted.
    const stats = { ...rawStats, totalInvoicedValue: canViewCommercialValues(role) ? rawStats.totalInvoicedValue : null }
    const jobs = clientDb.jobsForClient(id, 50)
    return NextResponse.json({ client, stats, jobs })
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 500 })
  }
}

export async function PATCH(req: NextRequest, { params }: Ctx) {
  try {
    const { id } = await params
    let body: Record<string, unknown>
    try { body = await req.json() }
    catch { return NextResponse.json({ error: "Invalid JSON" }, { status: 400 }) }

    if (body.name !== undefined) {
      const name = String(body.name).trim()
      if (!name) return NextResponse.json({ error: "Company name cannot be empty" }, { status: 422 })
      // Duplicate check (excluding self)
      const existing = clientDb.findByName(name)
      if (existing && existing.id !== id) {
        return NextResponse.json({
          error: `A client named "${existing.name}" already exists.`, existing,
        }, { status: 409 })
      }
    }

    const updated = clientDb.update(id, {
      ...(body.name          !== undefined && { name:           String(body.name).trim() }),
      ...(body.contactName   !== undefined && { contactName:    body.contactName   ? String(body.contactName).trim()   : null }),
      ...(body.email         !== undefined && { email:          body.email         ? String(body.email).trim()         : null }),
      ...(body.phone         !== undefined && { phone:          body.phone         ? String(body.phone).trim()         : null }),
      ...(body.billingAddress!== undefined && { billingAddress: body.billingAddress ? String(body.billingAddress).trim(): null }),
      ...(body.notes         !== undefined && { notes:          body.notes         ? String(body.notes).trim()         : null }),
      ...(body.accountCode   !== undefined && { accountCode:    body.accountCode   ? String(body.accountCode).trim()   : null }),
      ...(body.active        !== undefined && { active:         body.active ? 1 : 0 }),
    })
    if (!updated) return NextResponse.json({ error: "Not found" }, { status: 404 })
    return NextResponse.json(updated)
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 500 })
  }
}

export async function DELETE(_req: NextRequest, { params }: Ctx) {
  try {
    const { id } = await params
    // Archive rather than hard-delete if client has jobs
    const stats = clientDb.stats(id)
    if (stats.totalJobs > 0) {
      const archived = clientDb.archive(id)
      if (!archived) return NextResponse.json({ error: "Not found" }, { status: 404 })
      return NextResponse.json({ archived: true, client: archived })
    }
    const ok = clientDb.delete(id)
    if (!ok) return NextResponse.json({ error: "Not found" }, { status: 404 })
    return NextResponse.json({ deleted: true })
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 500 })
  }
}
