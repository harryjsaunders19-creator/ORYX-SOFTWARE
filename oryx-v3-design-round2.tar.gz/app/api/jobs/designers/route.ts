import { NextResponse } from "next/server"
import { jobDb } from "@/lib/db"

export async function GET() {
  try {
    return NextResponse.json({ designers: jobDb.distinctDesigners() })
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 500 })
  }
}
