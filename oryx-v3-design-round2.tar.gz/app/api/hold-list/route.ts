import { NextResponse } from "next/server"
import { holdDb } from "@/lib/db"

export async function GET() {
  try {
    const holds = holdDb.allActive()
    return NextResponse.json({ holds, total: holds.length })
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 500 })
  }
}
