import { NextResponse } from "next/server"
import { quoteLineItemDb } from "@/lib/db"

type Ctx = { params: Promise<{ id: string }> }

export async function GET(_req: Request, { params }: Ctx) {
  const { id } = await params
  const lineItems = quoteLineItemDb.findForQuote(id)
  return NextResponse.json({ lineItems })
}
